package com.company.Exceptions;

public class NiepoprawnyFormatPESEL extends Exception{
    String PESEL;

    public NiepoprawnyFormatPESEL(String message, String PESEL){
        super(message);
        this.PESEL = PESEL;
    }

    public String getPESEL(){
        return PESEL;
    }
}
