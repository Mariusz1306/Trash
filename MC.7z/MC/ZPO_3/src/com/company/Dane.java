package com.company;

public class Dane {
    int day;
    int month;
    int year;
    boolean male;

    public Dane(String PESEL){
        this.year = Integer.parseInt(PESEL.substring(0,2));
        this.month = Integer.parseInt(PESEL.substring(2,4));
        this.day = Integer.parseInt(PESEL.substring(4,6));
        int sex = Integer.parseInt(PESEL.substring(10));
        if (sex % 2 != 0){
            this.male = true;
        } else {
            this.male = false;
        }
    }

    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public boolean isMale() {
        return male;
    }
}
