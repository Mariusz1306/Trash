package com.company;

import com.company.Exceptions.NiepoprawnyFormatPESEL;

import java.util.Scanner;

public class ZPO_3 {

    public static void main(String[] args) {
        String PESEL;
        Scanner scan = new Scanner(System.in);
        System.out.println("Podaj numer PESEL");
        PESEL = scan.nextLine();
        try {
            Integer.parseInt(PESEL);
            if (PESEL.length() != 10)
                throw new NiepoprawnyFormatPESEL("Pesel ma niepoprawny format", PESEL);
        } catch (NiepoprawnyFormatPESEL e){
            e.getMessage();
        } catch (NumberFormatException e){
            e.getMessage();
        }
        Dane dane = new Dane(PESEL);
        System.out.println("Rok: " + dane.getYear());
        System.out.println("Miesiac: " + dane.getMonth());
        System.out.println("Dzien: " + dane.getDay());
        if (dane.isMale())
            System.out.println("Mezczyzna");
        else
            System.out.println("Kobieta");
    }
}
