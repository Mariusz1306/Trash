package Convert;

public class ZPO_2 {

    public static void main(String[] args) {
        int number;
    }
}
