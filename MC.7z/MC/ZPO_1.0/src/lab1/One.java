package lab1;

public class One {
    public void test(){
        System.out.println("Dziala");
    }
}
