import lab1.One;

public class Main {

    public static void main(String[] args) {
        One one = new One();
        one.test();
    }

}
